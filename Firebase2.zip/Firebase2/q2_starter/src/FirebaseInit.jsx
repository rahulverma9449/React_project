import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCOSYQTUTvGxp5OgX_PZ62QOpggESMrHU8",
  authDomain: "blog-app-94ebf.firebaseapp.com",
  projectId: "blog-app-94ebf",
  storageBucket: "blog-app-94ebf.appspot.com",
  messagingSenderId: "699391996102",
  appId: "1:699391996102:web:91d3f1d4cca2d2162be7c7",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
