import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
function ErrorPage() {
  const navigate = useNavigate();

  useEffect(() => {
    setTimeout(() => navigate(-1), 3000);
  }, []);
  return (
    <>
      <main>
        <h1>OOPSS!!! Something Went Wrong</h1>
      </main>
    </>
  );
}

export default ErrorPage;
