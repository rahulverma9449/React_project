import React, { Component } from "react";

export class Form extends Component {
  constructor(props) {
    super(props);
    this.state = {
      text: "",
    };
  }

  handleChange = (e) => {
    this.setState({
      text: e.target.value,
    });
  };

  handleAdd = () => {
    const { text } = this.state;

    if (text.trim()) {
      // Call the onAdd prop with the current text value
      this.props.onAdd(text);

      // Clear the input field after adding the todo
      this.setState({ text: "" });
    }
  };

  render() {
    return (
      <div className="form">
        <input
          onChange={this.handleChange}
          value={this.state.text}
          placeholder="What's on your mind?"
          required
        />
        {/* Call handleAdd on button click to add the todos */}
        <button onClick={this.handleAdd}>Add</button>
      </div>
    );
  }
}
