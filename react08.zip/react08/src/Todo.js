import React, { Component } from "react";

export class Todo extends Component {
  render() {
    const { text, onRemove } = this.props;

    return (
      <div className="todo">
        <p>{text}</p>
        {/* Call onRemove prop when the "x" button is clicked */}
        <button onClick={onRemove}>x</button>
      </div>
    );
  }
}
