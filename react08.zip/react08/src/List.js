import React, { Component } from "react";
import { Todo } from "./Todo";

export class List extends Component {
  render() {
    const { todos, onRemove } = this.props;

    return (
      <div className="list">
        {/* Map through todos and render Todo component for each */}
        {todos.map((todo, index) => (
          <Todo key={index} text={todo.text} onRemove={() => onRemove(index)} />
        ))}
      </div>
    );
  }
}
