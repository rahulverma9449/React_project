import "./styles.css";
import { Component } from "react";
import { List } from "./List";
import { Form } from "./Form";

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      todos: [
        { text: "Do the laundry" },
        { text: "Iron the clothes" },
        { text: "Go for a walk" },
      ],
    };
  }

  handleAdd = (newTodoText) => {
    // Add a new Todo to the list
    this.setState((prevState) => ({
      todos: [...prevState.todos, { text: newTodoText }],
    }));
  };

  handleRemove = (index) => {
    // Remove the Todo from the list based on index
    this.setState((prevState) => {
      const updatedTodos = [...prevState.todos];
      updatedTodos.splice(index, 1);
      return { todos: updatedTodos };
    });
  };

  render() {
    const { todos } = this.state;

    return (
      <div className="App">
        <span>Todo</span>
        {/* Pass the todos list and functions as props to utilize them in the components for adding and removing */}
        <Form onAdd={this.handleAdd} />
        <List todos={todos} onRemove={this.handleRemove} />
      </div>
    );
  }
}
