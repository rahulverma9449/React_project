import { useEffect, useState } from "react";

export default function Input() {
  const [name, setName] = useState("Rahul");
  const [lastName, setLastname] = useState("Verma");
  const a = 0;

  useEffect(() => {
    document.title = name + " " + lastName;
  }, [name, lastName]);

  useEffect(() => {
    let timer = setInterval(() => {
      console.log("window width:", window.innerWidth);
    }, 2000);

    return clearInterval(timer);
  });

  return (
    <>
      <div className="section">
        <Row label="Name">
          <input
            className="input"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </Row>
        <Row label="Last Name">
          <input
            className="input"
            value={lastName}
            onChange={(e) => setLastname(e.target.value)}
          />
        </Row>
      </div>

      <h2>Hello, {name + " " + lastName}</h2>
    </>
  );
}

function Row(props) {
  const { label } = props;
  return (
    <>
      <label>
        {label}
        <br />
      </label>
      {props.children}
      <hr />
    </>
  );
}
