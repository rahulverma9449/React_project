import { useEffect } from "react";
import { List } from "../components/List";
// import comments actions here
import{
  fetchStart,
  fetchSuccess,
  fetchError
} from "../redux/reducers/commentsReducer";

import { useDispatch } from "react-redux";
export const Home = () => {
  const disptach = useDispatch();
  const getComments = async () => {
    try {
      const response = await fetch(
        "https://jsonplaceholder.typicode.com/comments"
      );
      const data = await response.json();
      disptach(fetchSuccess(data));
    } catch (e) {
      disptach(fetchError());
    }
  };

  useEffect(() => {
    // dispatch fetch start action here
    disptach(fetchStart());
    // execute the getComments function here
    getComments()
  }, []);

  return (
    <div className="home">
      <h3>Internet Comments</h3>
      <List />
    </div>
  );
};
