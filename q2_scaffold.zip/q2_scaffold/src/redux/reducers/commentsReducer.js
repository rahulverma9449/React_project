// import redux toolkit methods here
import {createSlice} from '@reduxjs/toolkit';
const INITIAL_STATE = { comments: [], isLoading: false, error: null };

// define comments reducer function here
const commentSlice = createSlice({
    name:'comment',
    initialState:INITIAL_STATE,
    reducers:{
        fetchStart:(state,action)=>{
            state.isLoading=true;
        },
        fetchSuccess: (state, action) => {
            state.comments = action.payload;
            state.isLoading = false;
          },
        fetchError:(state,action)=>{
            state.error="Failed to fetch comments.",
            state.isLoading = false
        }
    }
})
// export the comments reducer function and action creators here

// export the comments selector function here


export const commentReducer=commentSlice.reducer;

export const { fetchStart, fetchSuccess, fetchError } = commentSlice.actions;

//selector function
export const commentSelector = (state) => state.commentReducer;